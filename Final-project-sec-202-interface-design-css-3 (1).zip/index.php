<DOCTYPE! html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cloth Selling Website</title>
    
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bacasime+Antique&family=Chela+One&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
  <!-- <style>
    .intro{
       column-count: 3;
       column-gap: 40px;
       column-rule-width: 7px;
    }
   </style>-->
  </head>
  <body>
    <header>
      <div class="head">
      <div id="title"><h3> 100+ NEW MARKDOWNS JUST ADDED! ENJOY UP TO 40% OFF SALE STYLES | <span> <a href="#"> SHOP NOW</a></span></h3></div>
       <div class="home"> <li> <a href="#"><i class="fa-solid fa-house"></i></a></li></div>
      </div>
      <div class="intro">
        <p><img src="Canada Image.jpg" height=40 width=50> 
       One of the Canada's Stores
      <span class="icon">
        <i class="fa-solid fa-user" title="Sign in"></i>
      <i class="fa-solid fa-cart-shopping"title="Shopping Cart"></i>
        <i class="fa-regular fa-heart" title=""></i>
        <i class="fa-sharp fa-regular fa-globe"title="Customer Service"></i>
      </span>
      </p>
      </div>
        <h2> MICHAEL KORS</h2> 
      <div class="links">

      <a href="index.php"> Clothing </a>
       <a href="dresses.php"> Dresses</a>
       <a href="skirts.php"> Skirts </a>
       <a href="jeans.php"> Zeans </a>
       <a href="shirt.php">Shirts </a>
       <a href="beachwear.php"> Beachwear </a>
       <a href="top.php"> Tops </a>
       <a href="garments.php"> Under Garments </a>
       <a href="sportswear.php"> Sportswear </a>
       <a href="shorts.php"> Shorts </a>
      <form id="searchForm">
  <input type="text" id="searchInput"  placeholder="Search for clothes">
</form>

<div id="searchResults">
  <!-- Search results will be displayed here -->
</div>


  <img src="clothh.webp" height= 670px width="1470px">
      
    </header>
    <main>
      <div class="main">
        <div class="table">
        <table>
      <tbody>
        <tr> <th>Category</th> </tr>
        <tr> <td><ul style="list-style:circle;">
          <li class="link"><a style="color: green" href="dresses.php" data-replace="Dresses"><span>Dresses</span></a></li>
          <li class="link"><a style="color: green" href="skirts.php" data-replace="Skirts"><span>Skirts</span></a></li>
          <li class="link"><a style="color: green" href="jeans.php" data-replace="Jeans"><span>Jeans</span></a></li>
          <li class="link"><a style="color: green" href="shirt.php" data-replace="Shirts"><span>Shirts</span></a></li>
          <li class="link"><a style="color: green" href="beachwear.php" data-replace="Beachwear"><span>Beachwear</span></a></li>
          <li class="link"><a style="color: green" href="top.php" data-replace="Tops"><span>Tops</span></a></li>
          <li class="link"><a style="color: green" href="garments.php" data-replace="Undergarments"><span>Undergarments</span></a></li>
          <li class="link"><a style="color: green" href="sportswear.php" data-replace="Sportwear"><span>Sportwear</span></a></li>
          <li class="link"><a style="color: green" href="shorts.php" data-replace="Shorts"><span>Shorts</span></a></li>
         
        </ul></td> </tr>
        

        <tr> <th>Size </th> </tr>
        <tr> <td><ul style="list-style:circle;">
          <li>Small (S)</li>
          <li>Medium (M)</li>
          <li>Large (L)</li>
          <li> XL</li>
          <li>XXL</li>
          <li>XXXL</li>
          <li>XXXL</li> 
        </ul></td> </tr>
        
    
        <tr> <th>Style </th> </tr>
        <tr> <td><ul style="list-style:circle;">
          <li>Casual</li>
          <li>Elegant</li>
          <li> Boho</li>
          <li> Sexy</li>
          <li>Cute</li>
          <li>Modest</li>
         </ul></td> </tr>

        <tr> <th>Material</th> </tr>
           <tr> <td><ul style="list-style:circle;">
          <li>Silk</li>
          <li> Polyester</li>
          <li> Velvet</li>
          <li> Glitter</li>
          <li>Denim</li>
          <li>Modest Canvas</li>
          <li>Canvas</li>
         <li>Fabric</li> 
         </ul></td> </tr>
        
   
      
          <tr> <th> Pattern Type</th></tr>
          <tr> <td> <ul style="list-style:circle;">
            <li> Plain</li>
            <li> Heart</li>
            <li> Floral</li>
            <li> Letter</li>
            <li> Colorblock</li>
            <li> Stripped</li>
          </ul>
          </td></tr>
        
        <tr> <th> Sleeve Length</th></tr>
          <tr> <td> <ul style="list-style:circle;">
            <li> Long Sleeve </li>
            <li> Short Sleeve</li>
            <li> Sleeveless</li>
            <li> Half Sleeve</li>
            <li> Extralong Sleeve</li>
       
          </ul>
          </td></tr>
        </tbody>
    </table>
        </div> 
        <div class="shirt-heading" style="padding-left:30px;">
  <p><b>Women's Clothing  </b><small>(Showing popular products)</small></p>
</div>
      <div class="images">
       <div><a href="dresses.php"> <img src="dresses.webp" id='dress'></a>
       <p> Dresses</p></div>
        <div><a href="skirts.php"> <img src="skirts.jpeg"></a>
          <p> Skirts</p></div>
        <div><a href="jeans.php"><img src="zeans.webp"></a>
          <p> Zeans</p></div>
       <div><a href="shirt.php"> <img src="shirts.jpg"></a>
       <p> Shirts</p></div>
        <div><a href="beachwear.php"> <img src="beachwear.jpg" id="beachwear"></a>
        <p> Beachwear</p></div>
        <div><a href="top.php"><img src="top.jpg"></a>
        <p> Tops</p></div>
        <div><a href="garments.php"><img src="undergarments.webp"></a>
        <p class="garments"> Garments</p></div>
        <div><a href="sportswear.php"><img src="sportswear.webp"></a>
        <p> Sportswear</p></div>
        <div><a href="shorts.php"><img src="shorts.jpg"></a>
        <p> Shorts</p></div>
      </div>
      </div>
    </main>
   
    <footer>
   <?php include('footer.php');?>
</footer>
    
  </body>
</html>