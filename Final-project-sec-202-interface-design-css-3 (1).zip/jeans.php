<html>
  <head>
    <title></title>
     <link rel="stylesheet" href="style.css">
    
  </head>
  <body>
    <header>
      <?php include('header.php')?>
</header>
 <main class="main">
    <?php include('list.php')?>
<div class="shirt-heading">
  <p><b>Women's zeans  </b><small>(Showing popular products)</small></p>
</div>
<div class="jeans-grid">
  
  <div class="jeans-grid1">
    <a href="jns1.php" class="skirt-link">QUICK VIEW</a>
   
  </div>
  
  <div class="jeans-grid2">
     <a href="jns2.php" class="skirt-link">QUICK VIEW</a>
  </div>
  
  <div class="jeans-grid3">
     <a href="jns3.php" class="skirt-link">QUICK VIEW</a>
  </div>
  
  <div class="jeans-grid4">
     <a href="jns4.php" class="skirt-link">QUICK VIEW</a>
  </div>
  
  <div class="jeans-grid5">
    <p><b>HOTSUP</b><br>
Women Boyfriend Mid Rise Light Blue Jeans<br>
$20  <span class="discount">(20%off)</span></p>
  </div>
  
  <div class="jeans-grid6">
    <p><b>Amaara</b><br>
Women Boyfriend Mid Rise White Jeans<br>
 $80 <span class="discount">(53%off)</span></p>
  </div>
  
  <div class="jeans-grid7">
   <p><b> TYFFYN</b><br>
Women Slim High Rise Black Jeans<br>
 $85 <span class="discount">(15%off)</span></p>
  </div>
  
  <div class="jeans-grid8">
    <p>
      <b>TYFFYN</b><br>
Women Slim High Rise Blue Jeans<br>
$105 <span class="discount">(25%off)</span>
    </p>
  </div>
  
  <div class="jeans-grid9">
     <a href="jns5.php" class="skirt-link">QUICK VIEW</a>
  </div>
  
  <div class="jeans-grid10">
     <a href="jns6.php" class="skirt-link">QUICK VIEW</a>
  </div>
  
  <div class="jeans-grid11">
     <a href="jns7.php" class="skirt-link">QUICK VIEW</a>
  </div>
  
  <div class="jeans-grid12">
     <a href="jns8.php" class="skirt-link">QUICK VIEW</a>
  </div>
  
  <div class="jeans-grid13">
    <p>
      <b>KOTTY</b><br>
Women Regular High Rise Black Jeans<br>
$15 <span class="discount">(25%off)></span>
    </p>
  </div>
  
  <div class="jeans-grid14">
    <p>
      <b>Tokyo Talkies</b><br>
Women Regular Mid Rise Light Blue Jeans<br>
$55 <span class="discount">(75%off)></span>
    </p>
  </div>
  
  <div class="jeans-grid15">
    <b>SheLook</b><br>
Women Regular High Rise Blue Jeans<br>
$25 <span class="discount">(55%off)></span>
  </div>
  
  <div class="jeans-grid16">
   <b> SSP</b><br>
Women Boyfriend High Rise Blue Jeans<br>
 $40 <span class="discount">(75%off)></span>
  </div>
   
</div>
 </main>
<footer>
   <?php include('footer.php'); ?>
</footer>
  </body>
</html>