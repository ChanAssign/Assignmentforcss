<html>
  <head>
    <title></title>
     <link rel="stylesheet" href="style.css">
    
  </head>
  <body>
    <header>
      <?php include('header.php'); ?>
</header>
    <main class="main">
      <?php include('list.php')?>
<div class="shirt-heading">
  <p><b>Women's sportswear </b><small>(Showing popular products)</small></p>
</div>
<div class="swear-grid">
  <div class="swear-grid1">
     <a href="sw1.php" class="skirt-link">QUICK VIEW</a>
  </div>
   <div class="swear-grid2">
      <a href="sw2.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="swear-grid3">
      <a href="sw3.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="swear-grid4">
      <a href="sw4.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="swear-grid5">
  <b> women worth</b><br> 
Solid Women Black Cycling Shorts<br>
$75 <span class= "green-text">(40%off)</span>
   </div>
   <div class="swear-grid6">
   <b>women worth</b><br>
Pack of 2 Solid Women Grey,Black Cycling Shorts<br>
     $45 <span class= "green-text">(45%off)</span>
   </div>
   <div class="swear-grid7">
  <b> ADIDAS </b><br>
Solid Women Black Tights<br>
       $25 <span class= "green-text">(65%off)</span>   
   </div>
   <div class="swear-grid8">
 <b>NIKE</b><br> 
Solid Women Blue Tights<br>
   $65 <span class= "green-text">(15%off)</span>    
   </div>
   <div class="swear-grid9">
      <a href="sw5.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="swear-grid10">
      <a href="sw6.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="swear-grid11">
      <a href="sw7.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="swear-grid12">
      <a href="sw8.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="swear-grid13">
   <b> JOCKEY </b><br>
Solid Women Dark Blue Tights<br>
      $90 <span class= "green-text">(15%off)</span>  
   </div>
   <div class="swear-grid14">
   <b> B-Tuf</b><br> 
Solid Women Black Tights<br>
    $70 <span class= "green-text">(05%off)</span>      
   </div>
   <div class="swear-grid15">
   <b>SATAK </b><br>
Women Lycra Capri/ Calf Length Capri & Gym Capri <br>
      <span  class= "red-text">$10 <br>FINAL SALE</span><br>
      
   </div>
   <div class="swear-grid16">
   <b> Cultsport</b><br> 
Women Solid Round Neck Polyester Orange T-Shirt<br>
 $25 <span class= "green-text">(45%off)</span>     
   </div>
</div>
    </main>
<footer>
   <?php include('footer.php'); ?>
</footer>
  </body>
</html>