<DOCTYPE! html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cloth Selling Website</title>
    
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bacasime+Antique&family=Chela+One&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" >
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" ></script>
    <link rel="stylesheet" href="style.css">
  <style>
    .contain{
      margin-top:0;
    }
    
   </style>
  </head>
  <body>
    <header>
      <div class="head"> 
      <div id="title"><h3 style="font-size:20px;"> 100+ NEW MARKDOWNS JUST ADDED! ENJOY UP TO 40% OFF SALE STYLES | <span> <a href="#"> SHOP NOW</a></span></h3></div>
       <div class="home"> <li> <a href="index.php"><i class="fa-solid fa-house"></i></a></li></div>
      </div>      
      <div class="intro">
        <p><img src="Canada Image.jpg" height=40 width=50> 
       One of the Canada's Stores
      <span class="icon">
        <i class="fa-solid fa-user" title="Sign in"></i>
      <i class="fa-solid fa-cart-shopping"title="Shopping Cart"></i>
        <i class="fa-regular fa-heart" title=""></i>
        <i class="fa-sharp fa-regular fa-globe"title="Customer Service"></i>
      </span>
      </p>
      </div>
        <h2> MICHAEL KORS</h2> 
      <div class="links">

     <a href="index.php"> Clothing </a>
       <a href="dresses.php"> Dresses</a>
       <a href="skirts.php"> Skirts </a>
       <a href="jeans.php"> Zeans </a>
       <a href="shirt.php">Shirts </a>
       <a href="beachwear.php"> Beachwear </a>
       <a href="top.php"> Tops </a>
       <a href="garments.php"> Under Garments </a>
       <a href="sportswear.php"> Sportswear </a>
       <a href="shorts.php"> Shorts </a>
      <form id="searchForm"><input type="text" id= "searchInput" placeholder="Search for clothes"></form>
        <div id="searchResults">
        </div>
        </div>
  
      <img src="clothh.webp" height= 670px width="1470px">
    </header>
    <main>
      <section id="acc">
        
  <div class="mask d-flex align-items-center h-100 gradient-custom-3" style="padding-top: 50px;">
    <div class="container h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-12 col-md-9 col-lg-7 col-xl-6">
          <div class="card" style="border-radius: 15px;">
            <div class="card-body p-5">
              <h2 class="text-uppercase text-center mb-5">Create an account</h2>

              <form>

                <div class="form-outline mb-4">
                  <input type="text" id="form3Example1cg" class="form-control form-control-lg" />
                  <label class="form-label" for="form3Example1cg">Your Name</label>
                </div>

                <div class="form-outline mb-4">
                  <input type="email" id="form3Example3cg" class="form-control form-control-lg" />
                  <label class="form-label" for="form3Example3cg">Your Email</label>
                </div>

                <div class="form-outline mb-4">
                  <input type="password" id="form3Example4cg" class="form-control form-control-lg" />
                  <label class="form-label" for="form3Example4cg">Password</label>
                </div>

                <div class="form-outline mb-4">
                  <input type="text" id="form3Example4cdg" class="form-control form-control-lg" />
                  <label class="form-label" for="form3Example4cdg">Address</label>
                </div>

                <div class="form-check d-flex justify-content-center mb-5">
                  <input class="form-check-input me-2" type="checkbox" value="" id="form2Example3cg" />
                  <label class="form-check-label" for="form2Example3g">
                    I agree all statements in <a href="#!" class="text-body"><u>Terms of service</u></a>
                  </label>
                </div>

                <div class="d-flex justify-content-center">
                  <button type="button"
                    class="btn btn-success btn-block btn-lg gradient-custom-4 text-body"  name="save_student" >Register</button>
                </div>

                <p class="text-center text-muted mt-5 mb-0">Have already an account? <a href="#"
                    class="fw-bold text-body"><u>Login here</u></a></p>

              </form>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
      
    </main>
    <footer>
   <?php include('footer.php'); ?>
</footer>
  </body>
</html>