<?php
 include ('includes/header.php');
  require 'database.php';
?>


<main>


<h1 style="color: brown; text-shadow: 1px 1px white; text-align: center; justify-content: center;padding-top: 60px;">
  Welcome User</h1>
  <a href="login.php" style="color:white; background-color:brown; font-size: 20px;padding:5px;margin:100px;" > Logout</a>


</main>
<footer  class="text-center text-white " style="background-color: #0a4275;margin-top:350px;">
    <!-- Grid container -->
    <div style="margin-top:30px;" class="container p-4 pb-0">
     
      <section class="">
        <p class="d-flex justify-content-center align-items-center">
          <span class="me-3">Register for free</span>
          <button type="button" class="btn btn-outline-light btn-rounded">
            Sign up!
          </button>
        </p>
      </section>
      <!-- Section: CTA -->
    </div>
    <!-- Grid container -->

    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
      © 2020 Copyright:
      <a class="text-white" href="https://mdbootstrap.com/">CRUDInPHP.com</a>
    </div>
    <!-- Copyright -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </footer>
  <!-- Footer -->
</section>

</body>
</html>
  

