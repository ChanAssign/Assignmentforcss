<html>
  <head>
    <title></title>
     <link rel="stylesheet" href="style.css">
    
  </head>
  <body>
   <header>
     <?php include('header.php'); ?>
   </header>
 <main class="main">
   <div class="dress1">
    <div>
        <img src='skirtimage6.webp'>
    </div>
  <div class="second">
    <h1>ALYNE</h1>
    <div id="first">
        <p>
            $150 <br>
            <span>Size:</span>
            <li>XS</li>
            <li>S</li>
            <li>M</li>
            <li>L</li>
            <li>XL</li>
            <br>
            <br>
            <button type="submit">ADD TO BAG</button><br>
            <button type="submit">PICK UP IN STORE</button>
        </p>
    </div>
    <div class="third">
        <p>
            <li><span><i class="fa-regular fa-heart"></i>&nbsp&nbsp&nbsp&nbsp;Add to Favourites</span></li>
            <li><span><i class="fa-solid fa-pen-ruler"></i>&nbsp&nbsp&nbsp&nbsp;DESIGN</span></li>
            Make a statement with this solid flared black skirt. It offers a versatile and elegant look that's suitable for various occasions. Pair it with different tops and accessories to create stunning ensembles.
            <li style="padding-top:20px;"><span><i class="fa-sharp fa-solid fa-tape"></i>&nbsp&nbsp&nbsp;DETAILS</span></li>
        </p>
    </div>
    <div class="last">
        <li>Skirt</li>
        <li>Solid flared black</li>
        <li>Material: Linen</li> 
        <li>Hand wash</li>
        <li>Imported</li>
    </div>
</div>

</div>


     
 </main>
<footer>
   <?php include('footer.php'); ?>
</footer>
  </body>
</html>