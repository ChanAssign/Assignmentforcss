<html>
  <head>
    <title></title>
     <link rel="stylesheet" href="style.css">
    
  </head>
  <body>
    <header>
      <?php include('header.php'); ?>
</header>
 <main class="main">
    <?php include('list.php')?>
<div class="shirt-heading">
  <p><b>Women's Skirts  </b><small>(Showing popular products)</small></p>
</div>
    <div class="skirt-grid">
<div class="skirt-grid1">
  <a href="skt1.php" class="skirt-link">QUICK VIEW</a>
    
</div>

    <div class="skirt-grid2">
      <a href="skt2.php" class="skirt-link">QUICK VIEW</a>
    </div>
      
    <div class="skirt-grid3">
      <a href="skt3.php" class="skirt-link">QUICK VIEW</a>
    </div>
       <div class="skirt-grid4">
      <a href="skte1.php" class="skirt-link">QUICK VIEW</a>
    </div>
    <div class="skirt-grid5">
      <p><b>Women Dyed multicolour skirt</b><br>
        Size XS, S, M, L, XL<br>
        $20   <span class="green-text">(30% off)</span>
      </p>
    </div>
    <div class="skirt-grid6">
     <p> <b>AASK</b><br>
Women Solid Pleated Black Skirt<br>
$50  <span class="green-text">(20% off)</span><br>
Saver Deal<br></p>
    </div>
     <div class="skirt-grid7">
       <p><b>Dream Beauty Fashion</b><br>
Women Solid Pencil Beige Skirt<br>
$100    <span class="green-text">(53% off)</span></p>
     </div>
       <div class="skirt-grid8">
     <b>TIGERSNAKE</b><br>
Women Dyed Broomstick Multicolor Skirt<br>
         $100 <span class="green-text">(53% off)</span>
    </div>
     <div class="skirt-grid9">
       <a href="skt4.php" class="skirt-link">QUICK VIEW</a> 
     </div>
     <div class="skirt-grid10">
         <a href="skt5.php" class="skirt-link">QUICK VIEW</a> 
     </div>
     
     <div class="skirt-grid11">
        <a href="skt6.php" class="skirt-link">QUICK VIEW</a> 
     </div>
       <div class="skirt-grid12">
        <a href="skte2.php" class="skirt-link">QUICK VIEW</a> 
     </div>
    <div class="skirt-grid13">
      <p ><b>ZWERLON</b><br>
Women Solid Flared Multicolour<br>
      $120   <span class="green-text">(15% off)</span></p>
    </div>
    <div class="skirt-grid14">
      <p>
      <b>  ALYNE</b><br>
Women Solid Flared Black Skirt<br>
        $150   <span class="green-text">(20% off)</span>
      </p>
    </div>
    
<div class="skirt-grid15">
  <p><b>fashion krishna</b><br>
Women Solid Flared White Skirt<br>
$300   <span class="green-text">(75% off)</span><br>
</p>
</div>
      <div class="skirt-grid16">
  <b>Aahwan</b><br>
Women Solid Straight Black Skirt<br>
$300   <span class="green-text">(75% off)</span><br>
</p>
</div>
  </div>
    

 </main>
<footer>
   <?php include('footer.php'); ?>
</footer>
  </body>
</html>