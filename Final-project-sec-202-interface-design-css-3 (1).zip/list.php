<html>
  <head>
    <title></title>
  </head>
  <body>
    <div class="main">
        <div class="table">
        <table>
      <tbody>
        <tr> <th>Category</th> </tr>
        <tr> <td><ul style="list-style:circle;">
          <li class="link"><a style="color: green" href="dresses.php" data-replace="Dresses"><span>Dresses</span></a></li>
          <li class="link"><a style="color: green" href="skirts.php" data-replace="Skirts"><span>Skirts</span></a></li>
          <li class="link"><a style="color: green" href="jeans.php" data-replace="Jeans"><span>Jeans</span></a></li>
          <li class="link"><a style="color: green" href="shirt.php" data-replace="Shirts"><span>Shirts</span></a></li>
          <li class="link"><a style="color: green" href="beachwear.php" data-replace="Beachwear"><span>Beachwear</span></a></li>
          <li class="link"><a style="color: green" href="top.php" data-replace="Tops"><span>Tops</span></a></li>
          <li class="link"><a style="color: green" href="garments.php" data-replace="Undergarments"><span>Undergarments</span></a></li>
          <li class="link"><a style="color: green" href="sportswear.php" data-replace="Sportwear"><span>Sportwear</span></a></li>
          <li class="link"><a style="color: green" href="shorts.php" data-replace="Shorts"><span>Shorts</span></a></li>
          
        </ul></td> </tr>
        

        <tr> <th>Size </th> </tr>
        <tr> <td><ul style="list-style:circle;">
          <li>Small (S)</li>
          <li>Medium (M)</li>
          <li>Large (L)</li>
          <li> XL</li>
          <li>XXL</li>
          <li>XXXL</li>
          <li>XXXL</li> 
        </ul></td> </tr>
        
    
        <tr> <th>Style </th> </tr>
        <tr> <td><ul style="list-style:circle;">
          <li>Casual</li>
          <li>Elegant</li>
          <li> Boho</li>
          <li> Sexy</li>
          <li>Cute</li>
          <li>Modest</li>
         </ul></td> </tr>

        
        
        </tbody>
    </table>
        </div> 
   
  </body>
</html>