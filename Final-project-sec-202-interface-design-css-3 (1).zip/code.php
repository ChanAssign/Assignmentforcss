<?php

session_start();

require 'database.php';


if(isset($_POST['save_student'])){

    


    $name = mysqli_real_escape_string($con,$_POST['name']);
    $email =  mysqli_real_escape_string($con,$_POST['email']);
    $password = mysqli_real_escape_string($con,$_POST['password']);
    $address = mysqli_real_escape_string($con,$_POST['address']);
   



    if($name!= "" &&  $email!= "" &&  $password!= "" &&  $address!= ""){

    $query="INSERT INTO customer(name,email,password,address) VALUES('$folder','$name','$email','$password','$address')";

    $query_run= mysqli_query($con,$query);

    if($query_run){
        $_SESSION['message']= "Account Created Successfully";
        header("Location: index.php");
        exit(0);
    }
    else{
        $_SESSION['message']= "Account Not Created";
        header("Location: index.php");
        exit(0);
    }
    
}
  else{
        $_SESSION['message']= "Fill out the all the fields Correctly as per the below instructions. Thank You!";
        header("Location: contact us.php");
        exit(0);
    }
    
}
?>