<html>
  <head>
    <title></title>
     <link rel="stylesheet" href="style.css">
    
  </head>
  <body>
   <header>
     <?php include('header.php'); ?>
   </header>
 <main class="main">
   <div class="dress1">
    <div>
        <img src='top6.webp''>
    </div>
 <div class="second">
    <h1>Lulus Everyday Casual</h1>
    <div id="first">
        <p>
            $70 <br>
            <span>Size:</span>
            <li>XS</li>
            <li>S</li>
            <li>M</li>
            <li>L</li>
            <li>XL</li>
            <br>
            <br>
            <button type="submit">ADD TO BAG</button><br>
            <button type="submit">PICK UP IN STORE</button>
        </p>
    </div>
    <div class="third">
        <p>
            <li><span><i class="fa-regular fa-heart"></i>&nbsp&nbsp&nbsp&nbsp;Add to Favourites</span></li>
            <li><span><i class="fa-solid fa-pen-ruler"></i>&nbsp&nbsp&nbsp&nbsp;DESIGN</span></li>
            Make a statement with this Everyday Casual Grey Ribbed Knit Racerback Tank Top from Lulus. It offers a versatile and stylish look that's perfect for various occasions. Pair it with different bottoms and accessories to create fashionable outfits.
            <li style="padding-top:20px;"><span><i class="fa-sharp fa-solid fa-tape"></i>&nbsp&nbsp&nbsp;DETAILS</span></li>
        </p>
    </div>
    <div class="last">
        <li>Top</li>
        <li>Everyday Casual Grey Ribbed Knit Racerback Tank Top</li>
        <li>Material: Cotton</li> 
        <li>Hand wash</li>
        <li>Imported</li>
    </div>
</div>

   </div>  
 </main>
<footer>
   <?php include('footer.php'); ?>
</footer>
  </body>
</html>