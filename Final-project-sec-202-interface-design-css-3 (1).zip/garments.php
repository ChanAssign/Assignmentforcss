<DOCTYPE! html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cloth Selling Website</title>
    
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bacasime+Antique&family=Chela+One&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
  <!-- <style>
    .intro{
       column-count: 3;
       column-gap: 40px;
       column-rule-width: 7px;
    }
   </style>-->
  </head>
  <body>
    <header>
      <div class="head">
      <div id="title"><h3> 100+ NEW MARKDOWNS JUST ADDED! ENJOY UP TO 40% OFF SALE STYLES | <span> <a href="#"> SHOP NOW</a></span></h3></div>
       <div class="home"> <li> <a href="index.php"><i class="fa-solid fa-house"></i></a></li></div>
      </div>
      <div class="intro">
        <p><img src="Canada Image.jpg" height=40 width=50> 
       One of the Canada's Stores
      <span class="icon">
        <i class="fa-solid fa-user" title="Sign in"></i>
      <i class="fa-solid fa-cart-shopping"title="Shopping Cart"></i>
        <i class="fa-regular fa-heart" title=""></i>
        <i class="fa-sharp fa-regular fa-globe"title="Customer Service"></i>
      </span>
      </p>
      </div>
        <h2> MICHAEL KORS</h2> 
      <div class="links">

      <a href="index.php"> Clothing </a>
       <a href="dresses.php"> Dresses</a>
       <a href="skirts.php"> Skirts </a>
       <a href="jeans.php"> Zeans </a>
       <a href="shirt.php">Shirts </a>
       <a href="beachwear.php"> Beachwear </a>
       <a href="top.php"> Tops </a>
       <a href="garments.php"> Under Garments </a>
       <a href="sportswear.php"> Sportswear </a>
       <a href="shorts.php"> Shorts </a>
      <form id="searchForm"><input type="text" id= "searchInput" placeholder="Search for clothes"></form>
        <div id="searchResults">
        </div>
        </div>
  <img src="clothh.webp" height= 670px width="1470px">
      
    </header>
    <main>
      <div class="main">
        <div class="table">
        <table>
      <tbody>
        <tr> <th>Category</th> </tr>
        <tr> <td><ul style="list-style:circle;">
          <li class="link"><a style="color: green" href="dresses.php" data-replace="Dresses"><span>Dresses</span></a></li>
          <li class="link"><a style="color: green" href="skirts.php" data-replace="Skirts"><span>Skirts</span></a></li>
          <li class="link"><a style="color: green" href="jeans.php" data-replace="Jeans"><span>Jeans</span></a></li>
          <li class="link"><a style="color: green" href="shirt.php" data-replace="Shirts"><span>Shirts</span></a></li>
          <li class="link"><a style="color: green" href="beachwear.php" data-replace="Beachwear"><span>Beachwear</span></a></li>
          <li class="link"><a style="color: green" href="top.php" data-replace="Tops"><span>Tops</span></a></li>
          <li class="link"><a style="color: green" href="garments.php" data-replace="Undergarments"><span>Undergarments</span></a></li>
          <li class="link"><a style="color: green" href="sportswear.php" data-replace="Sportwear"><span>Sportwear</span></a></li>
          <li class="link"><a style="color: green" href="shorts.php" data-replace="Shorts"><span>Shorts</span></a></li>
          
        </ul></td> </tr>
        

        <tr> <th>Size </th> </tr>
        <tr> <td><ul style="list-style:circle;">
          <li>Small (S)</li>
          <li>Medium (M)</li>
          <li>Large (L)</li>
          <li> XL</li>
          <li>XXL</li>
          <li>XXXL</li>
          <li>XXXL</li> 
        </ul></td> </tr>
        
    
        <tr> <th>Style </th> </tr>
        <tr> <td><ul style="list-style:circle;">
          <li>Casual</li>
          <li>Elegant</li>
          <li> Boho</li>
          <li> Sexy</li>
          <li>Cute</li>
          <li>Modest</li>
         </ul></td> </tr>

        
        
        </tbody>
    </table>
        </div> 
        <div class="shirt-heading">
  <p><b>Women's UnderGarments  </b><small>(Showing popular products)</small></p>
</div>
      <div class="images">
       <div><a href="garment1.php"> <img src="garment1.webp" id='dress'></a>
       <p style="font-size:14px; padding-left:50px; color:purple; "> MICHAEL KORS<br>
          Cloud Longline Bra
Light Support
       $70</p></div>

        <div><a href="garment2.php"> <img src="garment2.webp" id='dress'></a>
       <p style="font-size:14px; padding-left:50px; color:purple; "> MICHAEL KORS<br>
         Rust Red Twist Front Tummy Control Bikni Set<br/>
       $30</p></div>
        
        <div><a href="garment3.php"> <img src="garment3.jpg" id='dress' ></a>
       <p style="font-size:14px; padding-left:50px; color:purple; "> MICHAEL KORS<br>
         Kinyanco 5-Pack Women's High Waist Tummy Control Panties Cotton Underwear No Muffin Top<br/>
       $30</p></div>
        
         <div><a href="garment4.php"> <img src="garment4.jpeg" id='dress' ></a>
       <p style="font-size:14px; padding-left:50px; color:purple; "> MICHAEL KORS<br>
           Womens Medium Support Racerback Every Day Fitness Sports Bra<br/>
       $30</p></div>
        
        <div><a href="garment5.php"> <img src="garment5.webp" id='dress' ></a>
       <p style="font-size:14px; padding-left:50px; color:purple; "> MICHAEL KORS<br>
          Tummy Control Shapewear Shorts for Women Shaping Boyshorts Body Shaper Shorts Thigh Slimmer<br/>
       $20</p></div>
        
        <div><a href="garment6.php"> <img src="garment6.webp" id='dress' ></a>
       <p style="font-size:14px; padding-left:50px; color:purple; "> MICHAEL KORS<br>
       Womens Underwear Cotton- Sexy Lace Hipster Bikini Panties Cheeky Soft Multipack<br/>
       $27</p></div>
        
        <div><a href="garment7.php"> <img src="garment7.jpg" id='dress' ></a>
       <p style="font-size:14px; padding-left:50px; color:purple; "> MICHAEL KORS<br>
          Women High Waisted Two Piece Bikini Set Racerback Bathing Suit Sporty Crop Top with Bottom<br/>
       $40</p></div>

       
        <div><a href="garment8.php"> <img src="garment8.webp" id='dress'></a>
       <p style="font-size:14px; padding-left:50px; color:purple; "> MICHAEL KORS<br>
        Chantilly Lace Underwire Bra<br/>
       $29</p></div>
        
      </div>
      </div>
    </main>
    <footer>
   <?php include('footer.php'); ?>
</footer>
  </body>
</html>