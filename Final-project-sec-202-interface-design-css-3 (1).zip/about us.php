<DOCTYPE! html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cloth Selling Website</title>
    
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bacasime+Antique&family=Chela+One&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
  <!-- <style>
    .intro{
       column-count: 3;
       column-gap: 40px;
       column-rule-width: 7px;
    }
   </style>-->
  </head>
  <body>
    <header>
       <div class="head">
      <div id="title"><h3> 100+ NEW MARKDOWNS JUST ADDED! ENJOY UP TO 40% OFF SALE STYLES | <span> <a href="#"> SHOP NOW</a></span></h3></div>
       <div class="home"> <li> <a href="index.php"><i class="fa-solid fa-house"></i></a></li></div>
      </div>
      <div class="intro">
        <p><img src="Canada Image.jpg" height=40 width=50> 
       One of the Canada's Stores
      <span class="icon">
        <i class="fa-solid fa-user" title="Sign in"></i>
      <i class="fa-solid fa-cart-shopping"title="Shopping Cart"></i>
        <i class="fa-regular fa-heart" title=""></i>
        <i class="fa-sharp fa-regular fa-globe"title="Customer Service"></i>
      </span>
      </p>
      </div>
        <h2> MICHAEL KORS</h2> 
      <div class="links">

      <a href="index.php"> Clothing </a>
       <a href="dresses.php"> Dresses</a>
       <a href="skirts.php"> Skirts </a>
       <a href="jeans.php"> Zeans </a>
       <a href="shirt.php">Shirts </a>
       <a href="beachwear.php"> Beachwear </a>
       <a href="top.php"> Tops </a>
       <a href="garments.php"> Under Garments </a>
       <a href="sportswear.php"> Sportswear </a>
       <a href="shorts.php"> Shorts </a>
     <form id="searchForm"><input type="text" id= "searchInput" placeholder="Search for clothes"></form>
        <div id="searchResults">
        </div>
        </div>
  
      <img src="clothh.webp" height= 670px width="1470px">
    </header>
    <main>
      <div class="about">
      <h1> ABOUT US</h1>
      <p>
        Michael Kors is a world-renowned, award-winning designer of luxury accessories and ready-to-wear. His namesake company, established in 1981, currently produces a range of products under his signature Michael Kors Collection, MICHAEL Michael Kors and Michael Kors Mens labels. These products include accessories, footwear, watches, jewelry, women’s and men’s ready-to-wear, wearable technology, eyewear and a full line of fragrance products.
<br>
        <br>
Michael Kors stores are operated, either directly or through licensing partners, in some of the most prestigious cities in the world, including New York, Los Angeles, Chicago, London, Milan, Paris, Munich, Dubai, Seoul, Tokyo, Hong Kong, Shanghai and Rio de Janeiro. The company prides itself on hiring and retaining diverse talent and providing an inclusive work environment for all, while celebrating global events and cultures that reflect the diversity, experiences and perspectives of people around the world.
      </p>
      </div>
        <div id="img">
      <img src="about1.webp" height="700px">
      <h2> Michael's  Story</h2>
      <p>Designer Michael Kors was raised in Merrick, Long Island, a suburban town 23 miles from New York City. His keen eye for fashion was evident at a young age: at five, he advised his mother, Joan, to cut the bows off her wedding dress for her second marriage. She removed the bows.</p>
        </div>
      <div class="img2">
       
      <p> Kors was successful from the start, designing chic, luxurious sportswear that was both glamorous and effortless. He built a reputation as a designer who understands how women live and how they want feel in their clothes—confident, at ease, indulged and in control. By combining pragmatism with an unerring sense of chic, Kors’ unique take on “all American sportswear” would eventually go global.</p>
         
       <img src="about2.jpg" height="700px">
      </div>
      <div class="img3">
        <div>
      <img src="about3.webp" height="700px">
        </div>
        <div>
      <h3> Michael Kors Collection</h3>
      <p> Michael Kors launched his all-American sportswear label in 1981, earning countless awards, an A-list clientele and global recognition for his luxurious take on sophisticated clothes designed for a woman’s everyday life. Synonymous with easy glamour, timelessness and a jet set lifestyle, the collection includes sophisticated separates and evening wear as well as shoes, handbags and other accessories.</p>
        </div>
      </div>
    </main>
    <footer>
   <?php include('footer.php'); ?>
</footer>
  </body>
</html>