<html>
  <head>
    <title></title>
     <link rel="stylesheet" href="style.css">
    
  </head>
  <body>
    <header>
      <?php include('header.php'); ?>
</header>
    <main class="main">
      <?php include('list.php')?>
<div class="shirt-heading">
  <p><b>Women's Tops </b><small>(Showing popular products)</small></p>
</div>
<div class="top-grid">
  <div class="top-grid1">
     <a href="tp1.php" class="skirt-link">QUICK VIEW</a>
  </div>
   <div class="top-grid2">
      <a href="tp2.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="top-grid3">
      <a href="tp3.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="top-grid4">
      <a href="tp4.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="top-grid5">
    Lulus Babe Alert Black Notched Strapless Bodysuit<br>
$75 <span class= "green-text">(40%off)</span>
   </div>
   <div class="top-grid6">
    Lulus Draw You In Black Sleeveless Lace Bustier Bodysuit<br>
     $45 <span class= "green-text">(45%off)</span>
   </div>
   <div class="top-grid7">
    Lulus Basically Effortless White Short Sleeve Scoop Neck Top<br>
       $25 <span class= "green-text">(65%off)</span>   
   </div>
   <div class="top-grid8">
    Lulus Let's Tie It Rust Orange Tie-Back Cropped Tank Top<br>
   $65 <span class= "green-text">(15%off)</span>    
   </div>
   <div class="top-grid9">
      <a href="tp5.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="top-grid10">
      <a href="tp6.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="top-grid11">
      <a href="tp7.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="top-grid12">
      <a href="tp8.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="top-grid13">
     Lulus Sweet Fling Black Mesh Tank Top<br>
      $90 <span class= "green-text">(1  5%off)</span>  
   </div>
   <div class="top-grid14">
    Lulus Everyday Casual Grey Ribbed Knit Racerback Tank Top<br>
    $70 <span class= "green-text">(05%off)</span>      
   </div>
   <div class="top-grid15">
    Lulus Good Luck Charm Black Polka Dot Short Sleeve Button-Up Top<br>
      <span  class= "red-text">$10 <br>FINAL SALE</span><br>
      
   </div>
   <div class="top-grid16">
    Lulus Let's Tie It Black Tie-Back Cropped Tank Top<br>
 $25 <span class= "green-text">(45%off)</span>     
   </div>
</div>
      
    </main>
<footer>
   <?php include('footer.php'); ?>
</footer>
  </body>
</html>