<DOCTYPE! html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cloth Selling Website</title>
    
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bacasime+Antique&family=Chela+One&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
  <!-- <style>
    .intro{
       column-count: 3;
       column-gap: 40px;
       column-rule-width: 7px;
    }
   </style>-->
  </head>
  <body>
    <header>
      <div class="head">
      <div id="title"><h3> 100+ NEW MARKDOWNS JUST ADDED! ENJOY UP TO 40% OFF SALE STYLES | <span> <a href="#"> SHOP NOW</a></span></h3></div>
       <div class="home"> <li> <a href="index.php"><i class="fa-solid fa-house"></i></a></li></div>
      </div>
      <div class="intro">
        <p><img src="Canada Image.jpg" height=40 width=50> 
       One of the Canada's Stores
      <span class="icon">
        <i class="fa-solid fa-user" title="Sign in"></i>
      <i class="fa-solid fa-cart-shopping"title="Shopping Cart"></i>
        <i class="fa-regular fa-heart" title=""></i>
        <i class="fa-sharp fa-regular fa-globe"title="Customer Service"></i>
      </span>
      </p>
      </div>
        <h2> MICHAEL KORS</h2> 
      <div class="links">

      <a href="index.php"> Clothing </a>
       <a href="dresses.php"> Dresses</a>
       <a href="skirts.php"> Skirts </a>
       <a href="jeans.php"> Zeans </a>
       <a href="shirt.php">Shirts </a>
       <a href="beachwear.php"> Beachwear </a>
       <a href="top.php"> Tops </a>
       <a href="garments.php"> Under Garments </a>
       <a href="sportswear.php"> Sportswear </a>
       <a href="shorts.php"> Shorts </a>
      <form id="searchForm"><input type="text" id= "searchInput" placeholder="Search for clothes"></form>
        <div id="searchResults">
        </div>
        </div>
  
       <img src="clothh.webp" height= 600px width="1470px">
    </header>
    <main>

        <div class="dress1">

          <div ><img src="beach6.webp"> </div>
        <div class="second">  <h1> Tropical Plants Print Sleeveless Holiday Straight Jumpsuit </h1>
        <div id="first"><p > $150 <br>
            <span>Color: </span>Peach<br>
          <span> Size: </span>
            <li> XXS</li>
                  <li> XS</li>
                  <li> S</li>
                  <li> M</li>
                  <li> L</li>
                  <li> XL</li>
            <br>
         <br>
            <button type="submit"> ADD TO BAG</button><br>
            <button type="submit"> PICK UP IN STORE</button>
           </p>
</div>
          <div class="third">
          <p>
            <li> <span><i class="fa-regular fa-heart"></i>&nbsp&nbsp&nbsp&nbsp;Add to Favourites</span></li>
             <li><span> <i class="fa-solid fa-pen-ruler"></i>&nbsp&nbsp&nbsp&nbsp;DESIGN</span></li>
         Adjustable spaghetti strap, smocked back waist, sexy v neck, backless, two hidden pockets, full length, high waist wide leg pants, boho floral print, loose long rompers, one piece sleeveless Jumpsuits, outfits for women

            <li style="padding-top:20px;"> <span><i class="fa-sharp fa-solid fa-tape"></i>&nbsp&nbsp&nbsp; DETAILS</span></li>
            </div>
<div class="last">
  <li>Boho Sleeveless</li>
  <li>	Regular Fit</li>
 <li> High Waist</li>
 <li>	Floral All-over print</li>
 <li>Machine wash or professional dry clean</li>
 
 <li>	95% Polyester, 5% Elastane</li>
          </p>

</div>
          
        </div>
          
        </div>
     
    </main>
   <footer>
   <?php include('footer.php'); ?>
</footer>
  </body>
</html>