function myFunction() {
  document.getElementById('searchInput').addEventListener('keydown', function(event) {
  if (event.key === 'Enter') {
    var searchInput = document.getElementById('searchInput').value;
    if (searchInput === 'dresses') {
      // Redirect to the dresses page
      window.location.href = 'dresses.php';
    } else {
      // Display a message for other search terms
      document.getElementById('searchResults').innerHTML = 'No results found for ' + searchInput;
    }
  }
});
}