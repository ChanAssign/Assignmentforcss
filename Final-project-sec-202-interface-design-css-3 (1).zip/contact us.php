<DOCTYPE! html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cloth Selling Website</title>
    
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bacasime+Antique&family=Chela+One&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="style.css">
  <!-- <style>
    .intro{
       column-count: 3;
       column-gap: 40px;
       column-rule-width: 7px;
    }
   </style>-->
  </head>
  <body>
    <header>
      <div class="head">
      <div id="title"><h3> 100+ NEW MARKDOWNS JUST ADDED! ENJOY UP TO 40% OFF SALE STYLES | <span> <a href="#"> SHOP NOW</a></span></h3></div>
       <div class="home"> <li> <a href="index.php"><i class="fa-solid fa-house"></i></a></li></div>
      </div>
      <div class="intro">
        <p><img src="Canada Image.jpg" height=40 width=50> 
       One of the Canada's Stores
      <span class="icon">
        <i class="fa-solid fa-user" title="Sign in"></i>
      <i class="fa-solid fa-cart-shopping"title="Shopping Cart"></i>
        <i class="fa-regular fa-heart" title=""></i>
        <i class="fa-sharp fa-regular fa-globe"title="Customer Service"></i>
      </span>
      </p>
      </div>
        <h2> MICHAEL KORS</h2> 
      <div class="links">

      <a href="index.php"> Clothing </a>
       <a href="dresses.php"> Dresses</a>
       <a href="skirts.php"> Skirts </a>
       <a href="jeans.php"> Zeans </a>
       <a href="shirt.php">Shirts </a>
       <a href="beachwear.php"> Beachwear </a>
       <a href="top.php"> Tops </a>
       <a href="garments.php"> Under Garments </a>
       <a href="sportswear.php"> Sportswear </a>
       <a href="shorts.php"> Shorts </a>
     <form id="searchForm"><input type="text" id= "searchInput" placeholder="Search for clothes"></form>
        <div id="searchResults">
        </div>
        </div>
  
     <img src="clothh.webp" height= 600px width="1470px">
    </header>
    <main>
      <div class="contact">

        <div class="sec1">
          
       <li> <i class="fa-solid fa-message"></i>&nbsp&nbsp&nbsp&nbsp;Chat With Us</li>
           
          <p>We’re available Monday through Friday from 9 AM to 9 PM EST, and Saturday & Sunday from 10 AM to 6 PM EST.</p>
          <button type="submit"> CHAT NOW </button>
        </div>
        <div class="sec2">
         <li> <i class="fa-solid fa-phone"></i>&nbsp&nbsp&nbsp&nbsp;Give Us a Call</li>
         <p> We’re available Monday through Friday from 9 AM to 9 PM EST, and Saturday & Sunday from 10 AM to 6 PM EST.</p>

          <h2>CUSTOMER SERVICE</h2>
         <p> 1-866-709-KORS (5677)
            Give us a call for TDD/TTY assistance 9 AM to 5 PM EST, Monday 
                through Friday.</p>

               <h3>  TDD/TTY </h3>
         <p> 1-855-TTY-KORS (889-5677)</p>
        </div>
         
        <div class="sec3">
         <li> <i class="fa-solid fa-envelope"></i>&nbsp&nbsp&nbsp&nbsp;Write to us</li>
          
               <p>  Fill out our form and a Style Consultant will contact you.</p>
      <button type="submit"> WRITE NOW </button>
        </div>
      </div>
    </main>
  <footer>
   <?php include('footer.php'); ?>
</footer>
  </body>
</html>