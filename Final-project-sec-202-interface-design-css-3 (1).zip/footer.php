<html>
  <head>
    <title></title>
  </head>
  <body>
    <footer>
      <div class="contain">
        <div class="foot1">
          <p> Company</p>
          <ul style="list-style: none;">
            <li><a href="about us.php"> About Us</a> </li>
            <li> Careers</li>
            <li> Investor Relations</li>
            <li> Supply Chain Disclosure</li>
            <li> Corporate Socail Responsiblity</li>
          </ul>
        </div>

        <div class="foot2">
          <p>My Account</p>
          <ul style="list-style: none;">
            <li><a href="Account.php">Create Account</a> </li>
            <li> Accounts</li>
            <li> Track My Order</li>
          </ul>
        </div>
        <div class="foot3">
          <p> Customer Service</p>
          <ul style="list-style: none;">
            <li><a href="contact us.php"> Contact Us</a> </li>
            <li> Returns & Exchanges</li>
            <li> Shipping Terms</li>
            <li> Warranty & Repair</li>
            <li> FAQ</li>
             <li> Payment cards</li>
           
          </ul>
        </div>
        <div class="foot4">
          <p> FIND US ON</p>
          <a href="https://www.facebook.com/MichaelKors/" style="color:white;"><i class="fa-brands fa-facebook"></i></a>
          <a href="https://www.instagram.com/michaelkors/" style="color:white;"><i class="fa-brands fa-instagram"></i></a>
          <a href="#" style="color:white;"><i class="fa-brands fa-twitter"></i></a>
          <a href="#" style="color:white;"><i class="fa-brands fa-youtube"></i></a>
          <a href="#" style="color:white;"><i class="fa-brands fa-square-snapchat"></i></a>
      </div>

        <div class= "foot5">
        <p id="sign"> Sign Up For updates for Michael Kors</p>
        <form>
          <input type="email" class="txt" name="email" id="email" placeholder="Enter your email"> 
          <button type="submit" class="btn"> Sign Up </button>

          </div>
        </div>  
    </footer>
  </body>
</html>