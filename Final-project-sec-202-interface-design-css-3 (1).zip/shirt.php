<html>
  <head>
    <title></title>
     <link rel="stylesheet" href="style.css">
    
  </head>
  <body>
    <header>
      <?php include('header.php')?>
</header>
    <main class="main">
      <?php include('list.php')?>
<div class="shirt-heading">
  <p><b>Women's Shirts  </b><small>(Showing popular products)</small></p>
</div>
<div class="shirt-grid">
  <div class="shirt-grid1">
     <a href="srt1.php" class="skirt-link">QUICK VIEW</a>
  </div>
   <div class="shirt-grid2">
      <a href="srt2.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="shirt-grid3">
      <a href="srt3.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="shirt-grid4">
      <a href="srt4.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="shirt-grid5">
    <b> TEKTARWI</b><br>
Women Regular Fit Solid Casual Shirt<br>
$75 <span class= "green-text">(40%off)</span>
   </div>
   <div class="shirt-grid6">
    <b> FUNDAY FASHION</b><br>
Women Regular Fit Self Desig<br>
     $45 <span class= "green-text">(45%off)</span>
   </div>
   <div class="shirt-grid7">
     <b>FUNDAY FASHION</b><br>
Women Regular Fit Solid Spread Collar Casual Shirt<br>
       $25 <span class= "green-text">(65%off)</span>   
   </div>
   <div class="shirt-grid8">
    <b> kamla</b><br>
Women Slim Fit Solid Mandarin Collar Casual Shirt<br>
   $65 <span class= "green-text">(15%off)</span>    
   </div>
   <div class="shirt-grid9">
      <a href="srt5.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="shirt-grid10">
      <a href="srt6.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="shirt-grid11">
      <a href="srt7.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="shirt-grid12">
      <a href="srt8.php" class="skirt-link">QUICK VIEW</a>
   </div>
   <div class="shirt-grid13">
     <b>FUNDAY FASHION</b><br>
Women Regular Fit Solid Collar Shirt<br>
      $90 <span class= "green-text">(15%off)</span>  
   </div>
   <div class="shirt-grid14">
    <b> FUNDAY FASHION</b><br>
Women Regular Fit Solid Casual Shirts<br>
    $70 <span class= "green-text">(05%off)</span>      
   </div>
   <div class="shirt-grid15">
    <b> EyeBogler</b><br>
Women Regular Fit Solid Formal Shirt<br>
      $10 <span class= "green-text">(85%off)</span>   
   </div>
   <div class="shirt-grid16">
    <b> Selvia</b><br>
Women Regular Fit Printed Shirt<br>
 $25 <span class= "green-text">(45%off)</span>     
   </div>
  
    </main>
<footer>
   <?php include('footer.php'); ?>
</footer>
  </body>
</html>